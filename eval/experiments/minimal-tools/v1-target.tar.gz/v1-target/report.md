# nosh real-model evaluation

Run: `minimal-v1-temp1`. Observation: `native-v1`. Source: `fee7dd62484c993651c441680ae996c0575d2e65`. Binary SHA-256: `23b004653809df2fddc973056551b3297486cd2ac879a75aa2279c0f191b217a`.

Harness source: `da49b2c135e0f3053eb8144e3b85f7dfef570676b6316ec80a00c7f015453041`.

Seeds: `[0, 1, 2, 3, 4]`; repeats: 2. Each scenario/seed starts a new process. The typo scenario does not load a model.

| Scenario | Passed/planned | Failed / error / missing | Steps (mean) | Confirmations (mean) | TTFT (median s) | Process time (median s) | Peak RSS (max MiB) |
|---|---:|---:|---:|---:|---:|---:|---:|
| language-lines | 1/10 (10%) | 9 / 0 / 0 | 3.60 | 0.10 | 5.87 | 29.90 | 2437.19 |
| suggest-archive | 4/10 (40%) | 6 / 0 / 0 | 1.00 | 0.00 | 1.34 | 4.29 | 2318.50 |

TTFT is the engine's first-step time to its first sampled token, excluding model loading. Process time includes loading, terminal interactions, and shutdown, but excludes fixture setup. A fresh process has a cold conversation/KV cache, not necessarily a cold OS page cache. RSS is Linux wait4 ru_maxrss for each nosh process (including the kernel's accounting of waited-for descendants, not a sum of a process tree); the listener/verifier are separate. Timing aggregates include failed executions with available measurements. JSON contains sample counts and all raw values.

The suite rebuilds the MVP task intents, not the unavailable original fixtures. These objective pass rates are not directly comparable to the old manual correctness grades or warm-session timings.

## Previous run
Compared with `20260925T060719.060987Z`: 20 paired trials, 5 pass-to-nonpass changes, 3 nonpass-to-pass changes. Unpaired current/previous: 0/80.
- suite_sha256 differs; paired deltas are descriptive, not a controlled regression
- harness sources differ; paired deltas are descriptive, not a controlled regression
- observed sampling parameters differ

| Scenario / seed / repeat | Before → after | Δ steps | Δ confirmations | Δ TTFT s | Δ time s | Δ RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| language-lines / 0 / 0 | fail → fail | -1.00 | 0.00 | -0.36 | -21.31 | -31.15 |
| language-lines / 1 / 0 | fail → fail | 0.00 | 0.00 | 1.09 | 1.14 | 16.32 |
| language-lines / 2 / 0 | pass → fail | -2.00 | 0.00 | 1.39 | -18.55 | 15.17 |
| language-lines / 3 / 0 | fail → fail | 0.00 | 0.00 | 0.45 | 9.12 | 57.18 |
| language-lines / 4 / 0 | fail → pass | -1.00 | 0.00 | 0.61 | -13.44 | 58.30 |
| suggest-archive / 0 / 0 | pass → fail | 0.00 | 0.00 | -1.08 | -2.92 | -37.78 |
| suggest-archive / 1 / 0 | fail → fail | 0.00 | 0.00 | -0.79 | -2.14 | 21.04 |
| suggest-archive / 2 / 0 | fail → pass | 0.00 | 0.00 | -0.82 | -3.16 | -33.73 |
| suggest-archive / 3 / 0 | fail → fail | 0.00 | 0.00 | -0.85 | -3.02 | -12.80 |
| suggest-archive / 4 / 0 | pass → pass | 0.00 | 0.00 | -0.67 | -2.52 | -40.99 |
| language-lines / 0 / 1 | fail → fail | 8.00 | 0.00 | 1.19 | 12.17 | 5.56 |
| language-lines / 1 / 1 | fail → fail | 0.00 | 0.00 | 1.93 | 12.06 | 41.13 |
| language-lines / 2 / 1 | fail → fail | -1.00 | 1.00 | 0.91 | -3.23 | -2.09 |
| language-lines / 3 / 1 | fail → fail | -1.00 | 0.00 | 0.98 | -27.64 | 19.62 |
| language-lines / 4 / 1 | fail → fail | -2.00 | 0.00 | 1.17 | -7.07 | 23.02 |
| suggest-archive / 0 / 1 | pass → fail | 0.00 | 0.00 | -0.80 | -1.93 | -33.64 |
| suggest-archive / 1 / 1 | pass → fail | 0.00 | 0.00 | -0.82 | -2.23 | -28.71 |
| suggest-archive / 2 / 1 | fail → pass | 0.00 | 0.00 | -0.69 | -2.78 | -37.18 |
| suggest-archive / 3 / 1 | pass → fail | 0.00 | 0.00 | -0.64 | -2.75 | -16.49 |
| suggest-archive / 4 / 1 | pass → pass | 0.00 | 0.00 | -0.86 | -2.78 | -26.69 |

## Repeatability
9/10 pairs have the same verdict and final state; 0 pairs lack usable execution evidence.

| Scenario / seed / repeat | Verdict + state consistent | Answer changed | Tools changed | Inputs changed |
|---|---|---|---|---|
| language-lines / 0 / 1 | true | true | true | true |
| language-lines / 1 / 1 | true | true | true | true |
| language-lines / 2 / 1 | true | true | true | true |
| language-lines / 3 / 1 | true | true | true | true |
| language-lines / 4 / 1 | false | true | true | true |
| suggest-archive / 0 / 1 | true | true | false | true |
| suggest-archive / 1 / 1 | true | true | false | true |
| suggest-archive / 2 / 1 | true | false | false | true |
| suggest-archive / 3 / 1 | true | true | false | true |
| suggest-archive / 4 / 1 | true | false | false | true |

Dynamic prompt time, tool/recent-command durations, and live PIDs can change model inputs. Answer/trace differences are not automatically inference nondeterminism. Interface inputs do not include all internally retained assistant tokens: unchanged interface records are not proof of identical token prompts. See per-trial interface inputs where available.

## Per-trial answers and evidence

Display copies below omit line-end whitespace; JSON retains the recorded answer text.

### language-lines / seed 0 / repeat 0: fail

- no unambiguous python line count
- no unambiguous rust line count
```text
Here are the line counts by file in this project:

| File | Lines |
|------|-------|
| `main.py` | 5 |
| `src/main.rs` | 6 |
| `lib/maths.py` | 5 |
| `tools/report.py` | 5 |
| `web/app.js` | 4 |
| `scripts/check.sh` | 4 |
| **Total** | **29** |

The project has files in Python, Rust, and JavaScript. The breakdown by file type is:
- **Python**: 3 files (2 Python files)
- **Rust**: 1 file
- **JavaScript**: 1 file
```

### language-lines / seed 1 / repeat 0: fail

- python: expected 15, found [5, 5, 5]
```text
Here's the line count by language:

| File | Lines | Language |
|------|-------|----------|
| main.py | 5 | Python |
| lib/maths.py | 5 | Python |
| tools/report.py | 5 | Python |
| src/main.rs | 6 | Rust/C |
| scripts/check.sh | 4 | Shell |
| web/app.js | 4 | JavaScript |

**Totals:** 29 lines across 6 files (3 Python, 1 Rust/C, 1 Shell, 1 JavaScript).

Note: `web/app.js` and `scripts/check.sh` are both counted as 4 lines each despite having no extension-based indicator.
```

### language-lines / seed 2 / repeat 0: fail

- incorrect total file count: 5
- python: expected 15, found [5, 10]
- rust: expected 6, found [4]
- no unambiguous shell line count
```text
Here's the breakdown of lines of code grouped by file:

- `src/main.rs`: 6 lines
- `web/app.js`: 4 lines
- `tools/report.py`: 5 lines
- `lib/maths.py`: 5 lines
- `main.py`: 5 lines

**Total:** 29 lines across 5 files

To group by language, you'd need to categorize these files by extension:

- **Python (.py):** main.py (5 lines), tools/report.py (5 lines), lib/maths.py (5 lines) → **15 lines**
- **TypeScript/Web (.rs):** src/main.rs (6 lines) → **6 lines**
- **JavaScript (.js):** web/app.js (4 lines) → **4 lines**

**Total by language:** 25 lines (Python), 10 lines (Rust/TypeScript), 4 lines (JavaScript)
```

### language-lines / seed 3 / repeat 0: fail

- incorrect total line count: 30
- incorrect total file count: 5
- python: expected 15, found [5, 5, 5, 15]
- no unambiguous shell line count
```text
Here's the line count by language in this project:

| Language | File | Lines |
|----------|------|-------|
| Rust     | `src/main.rs`     | 6     |
| JavaScript | `web/app.js`     | 4     |
| Python   | `tools/report.py` | 5     |
| Python   | `lib/maths.py`   | 5     |
| Python   | `main.py`        | 5     |

**Breakdown by language:**
- **Rust**: 6 lines (1 file)
- **JavaScript**: 4 lines (1 file)
- **Python**: 15 lines (3 files)
- **Total**: 30 lines across 5 files

There's a nested directory structure (`lib/`, `scripts/`, `src/`, `tools/`, `web/`), but only 5 Python/Rust/JS files were counted for this project.
```

### language-lines / seed 4 / repeat 0: pass

```text
Here are the lines of code grouped by language:

**Python (.py):**
- `tools/report.py`: 5 lines
- `lib/maths.py`: 5 lines
- `main.py`: 5 lines
- **Total: 15 lines**

**Rust (.rs):**
- `src/main.rs`: 6 lines
- **Total: 6 lines**

**JavaScript (.js):**
- `web/app.js`: 4 lines
- **Total: 4 lines**

**Bash/Shell (.sh):**
- `scripts/check.sh`: 4 lines
- **Total: 4 lines**

**Grand total: 29 lines of code**
```

### suggest-archive / seed 0 / repeat 0: fail

- nosh exit code: 1
- task did not complete: incomplete
- only tar with an optional cd is supported
```text
(no answer)
```

### suggest-archive / seed 1 / repeat 0: fail

- shell expansion/redirection is outside the allowed subset
```text
mkdir -p logs && tar -czvf logs.tar.gz logs/ 2>/dev/null || echo "logs directory is empty"
```

### suggest-archive / seed 2 / repeat 0: pass

```text
tar -czf logs.tar.gz logs/
```

### suggest-archive / seed 3 / repeat 0: fail

- only tar with an optional cd is supported
```text
mkdir -p logs && tar -czvf logs.tar.gz logs
```

### suggest-archive / seed 4 / repeat 0: pass

```text
tar -czvf logs.tar.gz logs/
```

### language-lines / seed 0 / repeat 1: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
## Summary

I was counting lines of code grouped by language in the project at `/tmp/nosh-eval-1000/language-lines/files/`. The directory structure has these key files:

- **main.py** (113 bytes) — Python
- **lib/maths.py** (93 bytes) — Python
- **scripts/check.sh** (66 bytes) — Shell script

I encountered errors trying to list subdirectories (`scripts/src/`, `src/`, `tools/`, `web/`) because those entries appeared to be directories but some may not actually exist or have listing issues. I was unable to explore further because I hit my tool call limit.

**Next step:** You would need to run commands like `find /tmp/nosh-eval-1000/language-lines/files -type f` and `wc -l` on each file to get exact line counts, then group by extension (`.py` → Python, `.sh` → Shell, etc.). The current approach of counting bytes isn't appropriate for line counting.
```

### language-lines / seed 1 / repeat 1: fail

- python: expected 15, found [5, 5, 5, 15]
```text
Here's the line count by language in the project:

**Total lines: 29**

| Language | File | Lines |
|----------|------|-------|
| Python   | main.py | 5 |
| Python   | lib/maths.py | 5 |
| Python   | tools/report.py | 5 |
| Rust     | src/main.rs | 6 |
| Shell   | scripts/check.sh | 4 |
| JavaScript | web/app.js | 4 |

**Breakdown:**
- **Python**: 15 lines (3 files)
- **Rust**: 6 lines (1 file)
- **JavaScript**: 4 lines (1 file)
- **Shell**: 4 lines (1 file)
```

### language-lines / seed 2 / repeat 1: fail

- python: expected 15, found [5, 5, 5, 15]
- no unambiguous shell line count
- The declared approval policy denied at least one command; see approval evidence.
```text
Here's the breakdown of lines of code by language in this project:

| Language | File | Lines |
|----------|------|-------|
| **Python** | `main.py` | 5 |
| **Python** | `tools/report.py` | 5 |
| **Python** | `lib/maths.py` | 5 |
| **JavaScript** | `web/app.js` | 4 |
| **Rust** | `src/main.rs` | 6 |
| **Total** | | **29** |

So you have 29 lines of code across 5 files, with Python dominating (3 files, 15 lines), followed by Rust (1 file, 6 lines), and JavaScript (1 file, 4 lines).
```

### language-lines / seed 3 / repeat 1: fail

- python: expected 15, found [5, 5, 5, 5]
```text
Here's the line count by language:

| File | Lines | Language |
|------|-------|----------|
| main.py | 5 | Python |
| scripts/check.sh | 4 | Shell |
| src/main.rs | 6 | Rust |
| web/app.js | 4 | JavaScript |
| tools/report.py | 5 | Python |
| lib/maths.py | 5 | Python |

**Total: 29 lines** across 6 files.

The breakdown shows Rust has the most lines (6), followed by Python files (3 files with 5 lines each).
```

### language-lines / seed 4 / repeat 1: fail

- no unambiguous python line count
- shell: expected 4, found [2]
```text
Here's the breakdown of lines of code by language in `/tmp/nosh-eval-1000/language-lines/files`:

**Total: 29 lines**

| Language | Files | Lines |
|----------|-------|-------|
| Python   | main.py, maths.py, report.py | 5 + 5 + 5 = **15** |
| JavaScript | app.js | 4 |
| Rust    | main.rs | 6 |
| Shell   | check.sh | 2 |

**Key observations:**
- **Python (3 files):** `main.py` (5), `maths.py` (5), `report.py` (5) — dominant contributor
- **Rust (1 file):** `main.rs` (6) — largest single file
- **JavaScript (1 file):** `app.js` (4)
- **Shell (1 file):** `check.sh` (2) — small
- `lib/` and `tools/` directories contain standard library/utility files but only `maths.py` (5 lines) shows up as a significant Python file

Note: Some files like `scripts/check.sh` and `src/main.rs` were identified via `head -1` heuristics rather than full line counting. The actual line counts above come from `wc -l`.
```

### suggest-archive / seed 0 / repeat 1: fail

- shell expansion/redirection is outside the allowed subset
```text
mkdir -p logs.tar.gz && tar -czf logs.tar.gz logs/ 2>/dev/null || { echo "error compressing logs"; }
```

### suggest-archive / seed 1 / repeat 1: fail

- only tar with an optional cd is supported
```text
mkdir -p logs && tar -czvf logs.tar.gz logs/
```

### suggest-archive / seed 2 / repeat 1: pass

```text
tar -czf logs.tar.gz logs/
```

### suggest-archive / seed 3 / repeat 1: fail

- only tar with an optional cd is supported
```text
mkdir -p logs && tar -czf logs.tar.gz -C . logs/
```

### suggest-archive / seed 4 / repeat 1: pass

```text
tar -czvf logs.tar.gz logs/
```
