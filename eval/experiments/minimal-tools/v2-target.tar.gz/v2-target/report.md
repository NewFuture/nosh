# nosh real-model evaluation

Run: `minimal-v2-target-temp1`. Observation: `native-v1`. Source: `5df7060f6b5a4a01dcb27b84592a00679a8ee262`. Binary SHA-256: `aa6ffbfdc6a4bdcecd3432d7dcc1290ea1487cd48cfc9d91075374409b8caa7f`.

Harness source: `da49b2c135e0f3053eb8144e3b85f7dfef570676b6316ec80a00c7f015453041`.

Seeds: `[0, 1, 2, 3, 4]`; repeats: 2. Each scenario/seed starts a new process. The typo scenario does not load a model.

| Scenario | Passed/planned | Failed / error / missing | Steps (mean) | Confirmations (mean) | TTFT (median s) | Process time (median s) | Peak RSS (max MiB) |
|---|---:|---:|---:|---:|---:|---:|---:|
| language-lines | 2/10 (20%) | 8 / 0 / 0 | 4.80 | 0.00 | 6.19 | 32.27 | 2531.02 |
| suggest-archive | 10/10 (100%) | 0 / 0 / 0 | 1.00 | 0.00 | 1.46 | 4.13 | 2323.83 |

TTFT is the engine's first-step time to its first sampled token, excluding model loading. Process time includes loading, terminal interactions, and shutdown, but excludes fixture setup. A fresh process has a cold conversation/KV cache, not necessarily a cold OS page cache. RSS is Linux wait4 ru_maxrss for each nosh process (including the kernel's accounting of waited-for descendants, not a sum of a process tree); the listener/verifier are separate. Timing aggregates include failed executions with available measurements. JSON contains sample counts and all raw values.

The suite rebuilds the MVP task intents, not the unavailable original fixtures. These objective pass rates are not directly comparable to the old manual correctness grades or warm-session timings.

## Previous run
Compared with `20260925T060719.060987Z`: 20 paired trials, 1 pass-to-nonpass changes, 6 nonpass-to-pass changes. Unpaired current/previous: 0/80.
- suite_sha256 differs; paired deltas are descriptive, not a controlled regression
- harness sources differ; paired deltas are descriptive, not a controlled regression
- observed sampling parameters differ

| Scenario / seed / repeat | Before → after | Δ steps | Δ confirmations | Δ TTFT s | Δ time s | Δ RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| language-lines / 0 / 0 | fail → fail | 0.00 | 0.00 | 0.05 | -10.63 | -24.21 |
| language-lines / 1 / 0 | fail → fail | 1.00 | 0.00 | 0.38 | 6.88 | 80.46 |
| language-lines / 2 / 0 | pass → fail | -1.00 | 0.00 | 0.49 | -17.76 | 33.46 |
| language-lines / 3 / 0 | fail → fail | 1.00 | 0.00 | 0.96 | 13.25 | -12.78 |
| language-lines / 4 / 0 | fail → fail | 7.00 | 0.00 | 1.88 | 53.19 | 68.79 |
| suggest-archive / 0 / 0 | pass → pass | 0.00 | 0.00 | -0.88 | -2.74 | -32.37 |
| suggest-archive / 1 / 0 | fail → pass | 0.00 | 0.00 | -0.55 | -2.80 | 26.18 |
| suggest-archive / 2 / 0 | fail → pass | 0.00 | 0.00 | -0.69 | -3.06 | -28.00 |
| suggest-archive / 3 / 0 | fail → pass | 0.00 | 0.00 | -0.64 | -3.04 | -7.45 |
| suggest-archive / 4 / 0 | pass → pass | 0.00 | 0.00 | -0.69 | -2.82 | -32.26 |
| language-lines / 0 / 1 | fail → fail | 0.00 | 0.00 | 1.43 | 9.43 | 37.91 |
| language-lines / 1 / 1 | fail → pass | 0.00 | 0.00 | 1.32 | -0.20 | 0.43 |
| language-lines / 2 / 1 | fail → pass | -1.00 | 0.00 | 1.56 | -9.38 | -21.29 |
| language-lines / 3 / 1 | fail → fail | -2.00 | 0.00 | 1.72 | -24.36 | -10.90 |
| language-lines / 4 / 1 | fail → fail | 7.00 | 0.00 | 1.14 | 111.76 | 130.69 |
| suggest-archive / 0 / 1 | pass → pass | 0.00 | 0.00 | -0.86 | -2.83 | -28.49 |
| suggest-archive / 1 / 1 | pass → pass | 0.00 | 0.00 | -0.74 | -2.71 | 7.48 |
| suggest-archive / 2 / 1 | fail → pass | 0.00 | 0.00 | -0.55 | -2.35 | -32.08 |
| suggest-archive / 3 / 1 | pass → pass | 0.00 | 0.00 | -0.65 | -3.15 | -7.71 |
| suggest-archive / 4 / 1 | pass → pass | 0.00 | 0.00 | -0.62 | -2.28 | -20.82 |

## Repeatability
8/10 pairs have the same verdict and final state; 0 pairs lack usable execution evidence.

| Scenario / seed / repeat | Verdict + state consistent | Answer changed | Tools changed | Inputs changed |
|---|---|---|---|---|
| language-lines / 0 / 1 | true | true | true | true |
| language-lines / 1 / 1 | false | true | true | true |
| language-lines / 2 / 1 | false | true | true | true |
| language-lines / 3 / 1 | true | true | true | true |
| language-lines / 4 / 1 | true | true | true | true |
| suggest-archive / 0 / 1 | true | false | false | true |
| suggest-archive / 1 / 1 | true | false | false | true |
| suggest-archive / 2 / 1 | true | false | false | true |
| suggest-archive / 3 / 1 | true | false | false | true |
| suggest-archive / 4 / 1 | true | false | false | true |

Dynamic prompt time, tool/recent-command durations, and live PIDs can change model inputs. Answer/trace differences are not automatically inference nondeterminism. Interface inputs do not include all internally retained assistant tokens: unchanged interface records are not proof of identical token prompts. See per-trial interface inputs where available.

## Per-trial answers and evidence

Display copies below omit line-end whitespace; JSON retains the recorded answer text.

### language-lines / seed 0 / repeat 0: fail

- python: expected 15, found [5, 5, 5, 15]
- javascript: expected 4, found [4, 4, 6]
```text
Here are the line counts grouped by language for this project:

| Language | File | Lines |
|----------|------|-------|
| Python | lib/maths.py | 5 |
| Python | main.py | 5 |
| Python | tools/report.py | 5 |
| Bash | scripts/check.sh | 4 |
| Rust | src/main.rs | 6 |
| JavaScript | web/app.js | 4 |

**Totals:**
- Python: 15 lines
- Rust: 6 lines
- JavaScript: 4 lines
- Bash: 4 lines

**Overall:** 29 lines across 6 files.

Key notes:
- Each file has relatively few lines (max 6).
- Python, Rust, and JavaScript each have 5–6 lines contributing to the top.
- The total of 29 lines is the sum of all files' line counts.
```

### language-lines / seed 1 / repeat 0: fail

- incorrect total line count: 29
- incorrect total file count: 6
- python: expected 15, found [10, 10]
- javascript: expected 4, found [4, 4, 4, 29]
```text
Here's the line count breakdown by language in the project:

**Python** (2 files): 10 lines
- `main.py`: 5 lines
- `tools/report.py`: 5 lines
- `lib/maths.py`: 5 lines

**Shell** (1 file): 4 lines
- `scripts/check.sh`: 4 lines

**Rust** (1 file): 6 lines
- `src/main.rs`: 6 lines

**JavaScript** (1 file): 4 lines
- `web/app.js`: 4 lines

**Total: 29 lines across 6 files**

Breakdown by language:
| Language | Lines |
|----------|-------|
| Python   | 10    |
| Shell    | 4     |
| Rust     | 6     |
| JavaScript | 4   |
```

### language-lines / seed 2 / repeat 0: fail

- python: expected 15, found [5, 5]
- no unambiguous javascript line count
- no unambiguous shell line count
```text
Here's the breakdown of lines of code grouped by file:

- **Python**: `main.py` (5 lines), `tools/report.py` (5 lines), `lib/maths.py` (5 lines)
- **Rust**: `src/main.rs` (6 lines)
- **JavaScript**: `web/app.js` (4 lines)
- **Shell**: `scripts/check.sh` (4 lines)

**Totals**: 29 lines of code across 7 files

Note: `main.py` appears in both Python and the top-level directory listing, but its 5 lines are counted once.
```

### language-lines / seed 3 / repeat 0: fail

- incorrect total line count: 31
- python: expected 15, found [10, 5, 5, 5]
```text
Here's the line count by language for this project:

| Language | Files | Total Lines |
|----------|-------|-------------|
| Python | 2 (`main.py`, `lib/maths.py`) | 10 |
| C/Rust | 1 (`src/main.rs`) | 6 |
| Shell | 1 (`scripts/check.sh`) | 4 |
| JavaScript | 1 (`web/app.js`) | 4 |

**Breakdown by file:**
- `main.py` — Python script — 5 lines
- `lib/maths.py` — Python script — 5 lines
- `src/main.rs` — C source — 6 lines
- `scripts/check.sh` — Shell script — 4 lines
- `web/app.js` — JavaScript — 4 lines
- `tools/report.py` — Python script — 5 lines

**Total: 31 lines of code** across 6 files.
```

### language-lines / seed 4 / repeat 0: fail

- task did not complete: incomplete
- incorrect total file count: 10
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
## Line Count Analysis

The project contains files with the following line counts:

| Lines | Files |
|-------|-------|
| 3 | 5 files |
| 4 | 2 files |
| 6 | 1 file |
| 29 | 1 file |

**Summary:** There are 10 files in total across various languages, with line counts ranging from 4 to 29 lines.

**Next steps:**
- If you need a detailed breakdown by file type/language, run a file search to see what each line count corresponds to.
- If you need a different output format (e.g., grouped by file type), let me know and I can refine the analysis.
```

### suggest-archive / seed 0 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 1 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 2 / repeat 0: pass

```text
tar -czf logs.tar.gz logs/
```

### suggest-archive / seed 3 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 4 / repeat 0: pass

```text
tar -czvf logs.tar.gz logs/
```

### language-lines / seed 0 / repeat 1: fail

- python: expected 15, found [5, 5, 5, 15]
```text
Here's the line count grouped by language in the project:

| Language | File | Lines |
|----------|------|-------|
| Python | main.py | 5 |
| Python | tools/report.py | 5 |
| Python | lib/maths.py | 5 |
| Rust | src/main.rs | 6 |
| Shell | scripts/check.sh | 4 |
| JavaScript | web/app.js | 4 |

**Total: 29 lines across 6 files**

Key observations:
- **Python** dominates with 3 files (15 lines)
- **Rust** is the most concentrated language with 1 file but 6 lines
- No files with .js, .ts, .rb, .go, etc.
- The `web/` directory has JS but only 4 lines
- `lib/`, `scripts/`, `tools/` each have single-file contributions
```

### language-lines / seed 1 / repeat 1: pass

```text
Here's the line count breakdown by language in this project:

| Language | Lines |
|----------|-------|
| Python   | 15    |
| Shell    | 4     |
| Rust     | 6     |
| JavaScript | 4    |
| **Total** | **29** |

The lines are spread across 6 files:
- `main.py` (5 lines) — Python
- `scripts/check.sh` (4 lines) — Shell
- `src/main.rs` (6 lines) — Rust
- `web/app.js` (4 lines) — JavaScript
- `tools/report.py` (5 lines) — Python
- `lib/maths.py` (5 lines) — Python

**Key command used:** `find /tmp/nosh-eval-1000/language-lines/files -type f -exec wc -l {} +` — this finds all files recursively and counts their line lengths in one pass.
```

### language-lines / seed 2 / repeat 1: pass

```text
Here's the line count by language in the project:

| File                  | Lines |
|----------------------|-------|
| `main.py`            | 5     |
| `src/main.rs`        | 6     |
| `web/app.js`         | 4     |
| `tools/report.py`    | 5     |
| `lib/maths.py`       | 5     |
| `scripts/check.sh`   | 4     |

**Totals: 29 lines** across 6 source files.

Key observations:
- Python: 2 files (`main.py`, `tools/report.py`, `lib/maths.py`) — 5 + 5 + 5 = **15 lines**
- Rust: 1 file (`src/main.rs`) — **6 lines**
- JavaScript: 1 file (`web/app.js`) — **4 lines**
- Bash: 1 file (`scripts/check.sh`) — **4 lines**

The project has a mix of languages with Python being the most common contributor to line counts.
```

### language-lines / seed 3 / repeat 1: fail

- no unambiguous shell line count
```text
Here's the line count breakdown by file in the project:

**Line counts:**
- `src/main.rs` — 6 lines (Rust)
- `web/app.js` — 4 lines (JavaScript)
- `tools/report.py` — 5 lines (Python)
- `lib/maths.py` — 5 lines (Python)
- `main.py` — 5 lines (Python)

**Total: 29 lines**

Grouped by language:
- **Rust (`.rs`):** 6 lines
- **JavaScript (`.js`):** 4 lines
- **Python (`.py`):** 15 lines (5 + 5 + 5)

Note: `main.py` also appears in the root directory, contributing to the Python total. The `lib/` and `scripts/` directories have no files with line counts.
```

### language-lines / seed 4 / repeat 1: fail

- task did not complete: incomplete
```text
Based on my analysis of the project at `/tmp/nosh-eval-1000/language-lines/files`, here are the line counts of code grouped by file:

**By File:**
- `./src/main.rs`: 6 lines
- `./tools/report.py`: 5 lines
- `./main.py`: 5 lines
- `./lib/maths.py`: 5 lines
- `./web/app.js`: 4 lines
- `./scripts/check.sh`: 4 lines

**By Language (total lines per language):**
- **Rust**: 6 lines
- **Python**: 15 lines (5+5+5)
- **JavaScript**: 4 lines
- **Shell script**: 4 lines
- **Total**: 29 lines

**Next steps:**
1. If you need per-language totals, I can provide those if you have additional files in other languages.
2. If you want a cleaner summary, I can re-run the analysis with better output formatting.
3. If you need to organize files by language into separate directories or reports, I can help with that too.
```

### suggest-archive / seed 0 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 1 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 2 / repeat 1: pass

```text
tar -czf logs.tar.gz logs/
```

### suggest-archive / seed 3 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 4 / repeat 1: pass

```text
tar -czvf logs.tar.gz logs/
```
