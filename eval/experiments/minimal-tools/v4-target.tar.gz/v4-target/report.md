# nosh real-model evaluation

Run: `minimal-v4-target-temp1`. Observation: `native-v1`. Source: `5a4c28c91e7d3385accd439e9fc730b45b78de3a`. Binary SHA-256: `1902dc9cf2ef26cfd9aae5d1985d890a2acc7b5a5e541cce89dee2ade5c93ca2`.

Harness source: `da49b2c135e0f3053eb8144e3b85f7dfef570676b6316ec80a00c7f015453041`.

Seeds: `[0, 1, 2, 3, 4]`; repeats: 2. Each scenario/seed starts a new process. The typo scenario does not load a model.

| Scenario | Passed/planned | Failed / error / missing | Steps (mean) | Confirmations (mean) | TTFT (median s) | Process time (median s) | Peak RSS (max MiB) |
|---|---:|---:|---:|---:|---:|---:|---:|
| language-lines | 0/10 (0%) | 10 / 0 / 0 | 7.90 | 0.00 | 6.56 | 97.19 | 2566.64 |
| suggest-archive | 9/10 (90%) | 1 / 0 / 0 | 1.00 | 0.00 | 1.40 | 4.08 | 2323.91 |

TTFT is the engine's first-step time to its first sampled token, excluding model loading. Process time includes loading, terminal interactions, and shutdown, but excludes fixture setup. A fresh process has a cold conversation/KV cache, not necessarily a cold OS page cache. RSS is Linux wait4 ru_maxrss for each nosh process (including the kernel's accounting of waited-for descendants, not a sum of a process tree); the listener/verifier are separate. Timing aggregates include failed executions with available measurements. JSON contains sample counts and all raw values.

The suite rebuilds the MVP task intents, not the unavailable original fixtures. These objective pass rates are not directly comparable to the old manual correctness grades or warm-session timings.

## Previous run
Compared with `20260925T060719.060987Z`: 20 paired trials, 2 pass-to-nonpass changes, 4 nonpass-to-pass changes. Unpaired current/previous: 0/80.
- suite_sha256 differs; paired deltas are descriptive, not a controlled regression
- harness sources differ; paired deltas are descriptive, not a controlled regression
- observed sampling parameters differ

| Scenario / seed / repeat | Before → after | Δ steps | Δ confirmations | Δ TTFT s | Δ time s | Δ RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| language-lines / 0 / 0 | fail → fail | 7.00 | 0.00 | 0.99 | 46.55 | -24.88 |
| language-lines / 1 / 0 | fail → fail | -1.00 | 0.00 | 0.98 | -6.95 | -5.14 |
| language-lines / 2 / 0 | pass → fail | 7.00 | 0.00 | 0.87 | 35.49 | 111.69 |
| language-lines / 3 / 0 | fail → fail | 2.00 | 0.00 | 1.66 | 40.86 | 20.29 |
| language-lines / 4 / 0 | fail → fail | -2.00 | 0.00 | 1.40 | -10.86 | -26.77 |
| suggest-archive / 0 / 0 | pass → pass | 0.00 | 0.00 | -0.61 | -2.55 | -32.00 |
| suggest-archive / 1 / 0 | fail → pass | 0.00 | 0.00 | -0.57 | -2.66 | 26.21 |
| suggest-archive / 2 / 0 | fail → pass | 0.00 | 0.00 | -0.73 | -2.95 | -28.32 |
| suggest-archive / 3 / 0 | fail → pass | 0.00 | 0.00 | -0.36 | -2.60 | -7.64 |
| suggest-archive / 4 / 0 | pass → pass | 0.00 | 0.00 | -0.64 | -2.82 | -32.40 |
| language-lines / 0 / 1 | fail → fail | 8.00 | 0.00 | 2.51 | 181.45 | 187.96 |
| language-lines / 1 / 1 | fail → fail | 1.00 | 0.00 | 1.69 | 156.38 | 119.37 |
| language-lines / 2 / 1 | fail → fail | 7.00 | 0.00 | 2.66 | 98.08 | 58.92 |
| language-lines / 3 / 1 | fail → fail | 7.00 | 0.00 | 1.54 | 59.23 | 63.41 |
| language-lines / 4 / 1 | fail → fail | 7.00 | 0.00 | 0.99 | 119.33 | 85.24 |
| suggest-archive / 0 / 1 | pass → pass | 0.00 | 0.00 | -0.82 | -2.72 | -28.37 |
| suggest-archive / 1 / 1 | pass → pass | 0.00 | 0.00 | -0.83 | -2.74 | 7.86 |
| suggest-archive / 2 / 1 | fail → pass | 0.00 | 0.00 | -0.82 | -2.91 | -32.20 |
| suggest-archive / 3 / 1 | pass → pass | 0.00 | 0.00 | -0.69 | -3.05 | -8.20 |
| suggest-archive / 4 / 1 | pass → fail | 0.00 | 0.00 | -0.78 | -2.60 | -21.52 |

## Repeatability
9/10 pairs have the same verdict and final state; 0 pairs lack usable execution evidence.

| Scenario / seed / repeat | Verdict + state consistent | Answer changed | Tools changed | Inputs changed |
|---|---|---|---|---|
| language-lines / 0 / 1 | true | true | true | true |
| language-lines / 1 / 1 | true | true | true | true |
| language-lines / 2 / 1 | true | true | true | true |
| language-lines / 3 / 1 | true | true | true | true |
| language-lines / 4 / 1 | true | true | true | true |
| suggest-archive / 0 / 1 | true | false | false | true |
| suggest-archive / 1 / 1 | true | false | false | true |
| suggest-archive / 2 / 1 | true | false | false | true |
| suggest-archive / 3 / 1 | true | false | false | true |
| suggest-archive / 4 / 1 | false | true | false | true |

Dynamic prompt time, tool/recent-command durations, and live PIDs can change model inputs. Answer/trace differences are not automatically inference nondeterminism. Interface inputs do not include all internally retained assistant tokens: unchanged interface records are not proof of identical token prompts. See per-trial interface inputs where available.

## Per-trial answers and evidence

Display copies below omit line-end whitespace; JSON retains the recorded answer text.

### language-lines / seed 0 / repeat 0: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
````text
## Summary

I've run a command to count lines of code in the `/tmp/nosh-eval-1000/language-lines/files` project, grouped by file size class (text files only, with line counts via `grep -c .`). The results are:

| Lines Count | Files |
|-------------|-------|
| 5           | 3     |
| 4           | 2     |
| 6           | 1     |

**Total:** 6 text files identified with varying line counts.

However, the command was repeatedly invoked due to system rate-limiting (step limit reached). The tool stopped before completion, so please verify the counts manually if needed by running:

```bash
cd /tmp/nosh-eval-1000/language-lines/files
find . -type f -exec sh -c 'file "$1" | grep -q "text" && grep -c . "$1" 2>/dev/null' _ {} \; 2>/dev/null | sort | uniq -c | sort -rn
```

**Next step:** To get a complete breakdown, consider checking the project structure with `ls -la` and reviewing file contents if the automated grouping is unclear.
````

### language-lines / seed 1 / repeat 0: fail

- no unambiguous python line count
- no unambiguous rust line count
```text
The project contains 6 files with a total of **29 lines of code**, grouped by file:

- `./scripts/check.sh` - 4 lines
- `./web/app.js` - 4 lines
- `./lib/maths.py` - 5 lines
- `./main.py` - 5 lines
- `./tools/report.py` - 5 lines
- `./src/main.rs` - 6 lines
```

### language-lines / seed 2 / repeat 0: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
## Summary

The `run_command` tool had an issue returning unique language filenames with their line counts. Based on the earlier output, here's what the project contains:

**Files found:**
- `./web/app.js` - JavaScript
- `./tools/report.py` - Python
- `./src/main.rs` - Rust
- `./scripts/check.sh` - Shell script
- `./main.py` - Python
- `./lib/maths.py` - Python

**Next step:** To get the actual line counts per language, you could:
1. Use `find . -type f -not -path '*/.*' -exec wc -l {} + | grep -v '/' | sort | uniq -c`
2. Or manually check each file with `wc -l < filename`
3. Then count by extension to group by language
```

### language-lines / seed 3 / repeat 0: fail

- python: expected 15, found [29, 4, 29]
- javascript: expected 4, found [5, 5]
- shell: expected 4, found [1]
```text
Based on my analysis of the project at `/tmp/nosh-eval-1000/language-lines/files`, here are the lines of code grouped by file type:

| Language/File Type | Lines |
|-------------------|-------|
| .py (Python)     | 29    |
| .py (Python)     | 4     |
| .js (JavaScript)| 5     |
| .rs (Rust)       | 6     |
| Other (shell)    | total |

The project contains 7 files with 84 total lines of code across these file types. The breakdown shows Python files contribute the most lines (29 lines in `lib/maths.py` plus 4 lines in `tools/report.py`), with JavaScript having 5 lines, Rust having 6 lines, and shell scripts having 1 line each (`scripts/check.sh`).
```

### language-lines / seed 4 / repeat 0: fail

- incorrect total line count: 13
- incorrect total file count: 5
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
Here's the count of lines of code grouped by file:

- **5 lines**: 1 file
- **4 lines**: 2 files
- **6 lines**: 1 file
- **29 lines**: 1 file

The project has a total of 13 lines of code across 5 files.
```

### suggest-archive / seed 0 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 1 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 2 / repeat 0: pass

```text
tar -czf logs.tar.gz logs/
```

### suggest-archive / seed 3 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 4 / repeat 0: pass

```text
tar -czvf logs.tar.gz logs/
```

### language-lines / seed 0 / repeat 1: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
Based on my analysis, here are the results of counting lines of code grouped by language in the project:

**Lines per file:**
- 1 line: `./web/app.js`
- 1 line: `./tools/report.py`
- 1 line: `./src/main.rs`
- 1 line: `./scripts/check.sh`
- 1 line: `./main.py`
- 1 line: `./lib/maths.py`

There are 6 files with 1 line each, totaling **6 lines of code** across the project.

**Suggested next step:**
To get a more complete picture of the codebase, you should:
1. Verify these are actually code files and not empty or placeholder files
2. Check if there are additional files not captured by the search (e.g., binary files, directories)
3. If the goal is to understand the project structure, consider examining the actual contents of these files to determine if they contain meaningful code or are empty

Would you like me to explore any of these files further or run additional analysis?
```

### language-lines / seed 1 / repeat 1: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
(no answer)
```

### language-lines / seed 2 / repeat 1: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
Based on my analysis of the project at `/tmp/nosh-eval-1000/language-lines/files`, here are the results:

**Lines of code by file:**
- 1 file with 6 lines: `./web/app.js`
- 3 files with 5 lines each: `./src/main.rs`, `./tools/report.py`, `./lib/maths.py`
- 2 files with 4 lines each: `./scripts/check.sh`, `./web/app.js`
- 1 file with 4 lines: `./main.py`

**Key observations:**
- The total line count across all files is 29
- Most files (3 out of 7) have 5 lines
- No files have significantly more than 6 lines

**Next steps:**
1. To get a complete picture, you could run a more detailed count by file path using `wc -l` on each file individually
2. If you need a breakdown by language type (e.g., Python, JavaScript, Rust), you'd need to use `file` command to categorize each file
3. Consider whether the goal is to count only actual code lines (excluding comments/whitespace) or all non-blank lines
```

### language-lines / seed 3 / repeat 1: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
[task summary] I attempted to count lines of code grouped by language in the project at `/tmp/nosh-eval-1000/language-lines/files`. The tool probing method had a bug — it was only capturing the first letter of each file name rather than the file's actual language content. However, the total line count across all files is **29 lines**.

The files found are:
- `./scripts/check.sh`
- `./src/main.rs`
- `./web/app.js`
- `./tools/report.py`
- `./lib/maths.py`
- `./main.py`

[next steps] To get accurate line counts by language, you would need to: (1) properly identify each file's language, and (2) run `wc -l` on each file individually or use a script like `find . -type f -exec wc -l {} +` with per-file aggregation, then group by the identified language. The current results are unreliable because the language detection was flawed.
```

### language-lines / seed 4 / repeat 1: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
Based on my analysis of the `/tmp/nosh-eval-1000/language-lines/files` directory, here are the results:

**Files found (6 total):**
- `./scripts/check.sh` (line count: 4)
- `./src/main.rs` (line count: 5)
- `./web/app.js` (line count: 5)
- `./tools/report.py` (line count: 6)
- `./lib/maths.py` (line count: 6)
- `./main.py` (line count: 6)

**Grouped by file count (most common lines first):**
- **6 lines:** `tools/report.py`, `lib/maths.py`, `main.py`
- **5 lines:** `src/main.rs`, `web/app.js`
- **4 lines:** `scripts/check.sh`

**Next step:** If you need more accurate language-based grouping (e.g., Rust files vs Python files), you may want to identify which files belong to which programming languages using tools like `file` or `grep` on the filenames, then recount by language. The current method just counts all text files regardless of language.
```

### suggest-archive / seed 0 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 1 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 2 / repeat 1: pass

```text
tar -czf logs.tar.gz logs/
```

### suggest-archive / seed 3 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 4 / repeat 1: fail

- expected gzip creation at logs.tar.gz
```text
tar czf logs.tar.gz logs/
```
