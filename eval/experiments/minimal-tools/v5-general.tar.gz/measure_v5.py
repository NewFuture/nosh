import json
import os
from pathlib import Path
import subprocess
import time

scratch = Path(__file__).parent
deps = Path.home() / ".cache/nosh-minimal-tools-target/debug/deps"
args = ["rustc", "--edition=2024", str(scratch / "measure_v5.rs"),
        "-L", f"dependency={deps}", "-o", "/tmp/nosh-measure-v5"]
for name in ("nosh_core", "nosh_shell", "nosh_llm", "serde_json"):
    lib = max(deps.glob(f"lib{name}-*.rlib"), key=lambda p: p.stat().st_mtime)
    args += ["--extern", f"{name}={lib}"]
subprocess.run(args, check=True)
env = {**os.environ, "PATH": "/usr/bin:/bin", "USER": "eval", "LOGNAME": "eval"}
output = subprocess.check_output(
    ["/tmp/nosh-measure-v5", str(Path.home() / ".local/share/nosh/models/minicpm5-2b-q4_k_m/tokenizer.json")],
    env=env, text=True)
Path("eval/results/minimal-v5-prefix.json").write_text(output)
print(output, flush=True)
Path("/tmp/nosh-measure-v5").unlink()

def sample():
    ticks = {}
    for p in Path("/proc").iterdir():
        if p.name.isdigit() and (p / "comm").exists():
            try:
                comm = (p / "comm").read_text().strip()
                if comm in {"nosh", "cargo", "rustc"}:
                    fields = (p / "stat").read_text().split()
                    ticks[p.name] = {"comm": comm, "ticks": int(fields[13]) + int(fields[14])}
            except FileNotFoundError:
                continue
    mem = {line.split(":")[0]: int(line.split()[1]) for line in Path("/proc/meminfo").read_text().splitlines()}
    return ticks, {k: mem[k] for k in ("MemAvailable", "SwapFree", "SwapTotal")}

before, mem_before = sample()
time.sleep(5)
after, memory = sample()
delta = {p: after[p]["ticks"] - before[p]["ticks"] for p in before if p in after}
assert all(v["comm"] == "nosh" for v in after.values()), after
assert set(after) <= {"460", "747", "763", "308363"}, after
assert max(delta.values(), default=0) < 50, delta
assert memory["MemAvailable"] > 8 * 1024 * 1024, memory
assert memory["SwapFree"] >= mem_before["SwapFree"], memory
result = {"cpu_ticks_5s": delta, "processes": after, "memory_kib": memory, "existing_repls_preserved": True}
Path("eval/results/minimal-v5-initial-preflight.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result), flush=True)
