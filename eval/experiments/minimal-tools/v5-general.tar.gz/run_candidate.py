import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

version, phase = sys.argv[1:3]
binary = Path.home() / ".cache/nosh-minimal-tools-target/release/nosh"
root = Path("eval/results")
root.mkdir(exist_ok=True)
build = {
    "schema_version": 1,
    "source_revision": os.environ["NOSH_BUILD_REVISION"],
    "source_clean": True,
    "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
    "command": "env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR=$HOME/.cache/nosh-minimal-tools-target cargo build --release --locked -p nosh-cli --bin nosh",
    "rustc": subprocess.check_output(["rustc", "--version"], text=True).strip(),
}
build_path = root / f"minimal-{version}-build.json"
if build_path.exists():
    assert json.loads(build_path.read_text()) == build
else:
    build_path.write_text(json.dumps(build, indent=2) + "\n")

def snapshot():
    ticks = {}
    for pid in [460, 747, 763, 308363]:
        p = Path(f"/proc/{pid}/stat")
        if p.exists():
            fields = p.read_text().split()
            ticks[pid] = int(fields[13]) + int(fields[14])
    mem = {line.split(":")[0]: int(line.split()[1]) for line in Path("/proc/meminfo").read_text().splitlines()}
    return ticks, {k: mem[k] for k in ["MemAvailable", "SwapFree", "SwapTotal"]}

before, memory_before = snapshot()
time.sleep(5)
after, memory = snapshot()
delta = {p: after[p] - before[p] for p in before if p in after}
processes = subprocess.check_output(["ps", "-eo", "pid,comm,args"], text=True)
assert not any(line.split()[1] in {"cargo", "rustc"} for line in processes.splitlines()[1:])
assert all(int(line.split()[0]) in {460, 747, 763, 308363}
           for line in processes.splitlines()[1:] if line.split()[1] == "nosh"), processes
assert memory["MemAvailable"] > 8 * 1024 * 1024, memory
assert memory["SwapFree"] >= memory_before["SwapFree"], memory
assert max(delta.values(), default=0) < 50, delta
preflight = {"cpu_ticks_5s": delta, "memory_kib": memory, "existing_repls_preserved": True}
(root / f"minimal-{version}-{phase}-preflight.json").write_text(json.dumps(preflight, indent=2) + "\n")
print(json.dumps(preflight), flush=True)
args = [
    sys.executable, "-m", "eval.run",
    "--model-path", str(Path.home() / ".local/share/nosh/models/minicpm5-2b-q4_k_m"),
    "--binary", str(binary), "--build-info", str(build_path),
    "--seeds", "0", "1", "2", "3", "4",
    "--output", str(root / f"minimal-{version}-{phase}"),
    "--label", f"minimal-{version}-{phase}-temp1",
    "--compare", "eval/baselines/main-4f602ab/report.json",
]
if phase == "target":
    args += ["--scenario", "language-lines", "--scenario", "suggest-archive", "--repeat", "2"]
else:
    args += ["--repeat", "1"]
sys.exit(subprocess.run(args).returncode)
