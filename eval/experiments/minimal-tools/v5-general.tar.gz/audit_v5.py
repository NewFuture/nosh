from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import tarfile

run = Path("eval/results/minimal-v5-general")
destination = Path("eval/experiments/minimal-tools")
baseline_path = Path("eval/baselines/main-4f602ab/report.json")
candidate = json.loads((run / "report.json").read_text())
baseline = json.loads(baseline_path.read_text())
prefix = json.loads(Path("eval/results/minimal-v5-prefix.json").read_text())
rows = candidate["trials"]
assert len(rows) == 50
assert {r["repeat"] for r in rows} == {0}
assert all(s["missing"] == 0 for s in candidate["summary"])
assert all({r["seed"] for r in rows if r["scenario_id"] == s["scenario_id"]} == set(range(5))
           for s in candidate["summary"])
assert candidate["metadata"]["build"]["source_revision"] == "2c43aa96ec45e1a4c3de01c53075f829446d07da"
assert candidate["metadata"]["suite_sha256"] == baseline["metadata"]["suite_sha256"]
assert candidate["metadata"]["grading_content_sha256"] == baseline["metadata"]["grading_content_sha256"]
assert candidate["comparison"]["paired_trials"] == 50
assert candidate["metadata"]["settings"] == baseline["metadata"]["settings"]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def metrics(trials):
    result = {"planned": len(trials), **{s: sum(t["status"] == s for t in trials) for s in ("pass", "fail", "error")}}
    for key in ("steps", "ttft_s", "total_s", "peak_rss_mib", "confirmations"):
        values = [t["metrics"][key] for t in trials if t["metrics"].get(key) is not None]
        result[key] = {
            "samples": len(values),
            "mean": statistics.mean(values) if values else None,
            "median": statistics.median(values) if values else None,
            "max": max(values) if values else None,
        }
    return result

def calls(row):
    if row["tool_calls"] is not None:
        return row["tool_calls"]
    trace = run / row["logs"] / "engine.jsonl"
    assert trace.exists() or row["scenario_id"] == "typo-correction", row
    return [call for line in trace.read_text().splitlines()
            for call in json.loads(line).get("tool_calls", [])] if trace.exists() else []

for row in rows:
    for filename in ("stdout.txt", "stderr.txt", "transcript.txt"):
        assert (run / row["logs"] / filename).is_file()
    for event in row["inputs"] or []:
        if event.get("ev") != "open":
            continue
        tool_names = [t["name"] for t in event["tools"]]
        mode = "Suggest" if row["scenario_id"] == "suggest-archive" else (
            "ReadOnly" if row["scenario_id"] == "summarize-git-log" else "Full")
        expected = next(p for p in prefix if p["mode"] == mode)
        assert event["system"] == expected["system"], (row["scenario_id"], mode)
        assert event["tools"] == expected["tools"], (row["scenario_id"], mode)
        assert tool_names == [t["name"] for t in expected["tools"]]

old = {(r["scenario_id"], r["seed"]): r for r in baseline["trials"] if r["repeat"] == 0}
pairs = []
scenarios = []
for summary in candidate["summary"]:
    sid = summary["scenario_id"]
    current = [r for r in rows if r["scenario_id"] == sid]
    prior = [old[(sid, r["seed"])] for r in current]
    first = Counter((calls(r)[0]["name"] if calls(r) else "(none)") for r in current)
    tool_counts = Counter(c["name"] for r in current for c in calls(r))
    repeated = []
    for row in current:
        commands = [c["args"].get("command") for c in calls(row) if c["name"] == "run_command"]
        dupes = {c: n for c, n in Counter(commands).items() if n > 1}
        if dupes:
            repeated.append({"seed": row["seed"], "commands": dupes})
        before = old[(sid, row["seed"])]
        pairs.append({
            "scenario_id": sid, "seed": row["seed"], "repeat": 0,
            "before": before["status"], "after": row["status"],
            "before_answer": before["answer"], "after_answer": row["answer"],
            "before_reasons": before["reasons"], "after_reasons": row["reasons"],
            "before_tools": before["tool_calls"], "after_tools": calls(row),
            "before_metrics": before["metrics"], "after_metrics": row["metrics"],
            "sampling_before": before.get("sampling"), "sampling_after": row.get("sampling"),
            "approvals": row.get("approvals"),
        })
    scenarios.append({
        "scenario_id": sid, "baseline_repeat0": metrics(prior), "v5": metrics(current),
        "first_tools": dict(first), "tool_calls": dict(tool_counts),
        "repeated_commands": repeated,
        "regressed_seeds": [r["seed"] for r in current if old[(sid, r["seed"])]["status"] == "pass" and r["status"] != "pass"],
        "improved_seeds": [r["seed"] for r in current if old[(sid, r["seed"])]["status"] != "pass" and r["status"] == "pass"],
    })
audit = {
    "version": "v5/general",
    "primary_pairing_fixed_before_run": "formal main repeat0, matching scenario/seed; no candidate retries",
    "source_revision": candidate["metadata"]["build"]["source_revision"],
    "binary_sha256": candidate["metadata"]["build"]["binary_sha256"],
    "baseline_report_sha256": digest(baseline_path),
    "candidate_report_sha256": digest(run / "report.json"),
    "prefix": prefix,
    "overall": {
        "baseline_repeat0": metrics(list(old.values())),
        "v5": metrics(rows),
        "baseline_repeat1_sensitivity_only": metrics([r for r in baseline["trials"] if r["repeat"] == 1]),
        "v5_model_tasks": metrics([r for r in rows if r["scenario_id"] != "typo-correction"]),
    },
    "comparison": candidate["comparison"],
    "scenarios": scenarios,
    "pairs": pairs,
}
(destination / "v5-audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n")
archive = destination / "v5-general.tar.gz"
assert not archive.exists()
with tarfile.open(archive, "w:gz") as tar:
    tar.add(run, arcname="v5-general")
    for name in ("minimal-v5-build.json", "minimal-v5-prefix.json",
                 "minimal-v5-initial-preflight.json", "minimal-v5-general-preflight.json"):
        tar.add(Path("eval/results") / name, arcname=name)
    tar.add(Path(__file__), arcname="audit_v5.py")
    tar.add(Path(__file__).with_name("measure_v5.rs"), arcname="measure_v5.rs")
    tar.add(Path(__file__).with_name("measure_v5.py"), arcname="measure_v5.py")
    tar.add(Path(__file__).with_name("run_candidate.py"), arcname="run_candidate.py")
with tarfile.open(archive) as tar:
    assert hashlib.sha256(tar.extractfile("v5-general/report.json").read()).hexdigest() == audit["candidate_report_sha256"]
    assert sum(m.name.endswith("/stdout.txt") for m in tar.getmembers()) == 50
entry = {
    "version": "v5/general", "archive": archive.name, "archive_sha256": digest(archive),
    "report_sha256": audit["candidate_report_sha256"], "audit_sha256": digest(destination / "v5-audit.json"),
    "source_revision": audit["source_revision"], "binary_sha256": audit["binary_sha256"],
    "summary": candidate["summary"],
}
manifest_path = destination / "manifest.json"
manifest = json.loads(manifest_path.read_text())
assert not any(m["version"] == "v5/general" for m in manifest)
manifest.append(entry)
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({k: v for k, v in audit.items() if k not in ("pairs", "prefix", "comparison")}, indent=2))
print("warnings:", candidate["comparison"]["warnings"])
print("regressions:", [(p["scenario_id"], p["seed"]) for p in candidate["comparison"]["regressions"]])
print("improvements:", [(p["scenario_id"], p["seed"]) for p in candidate["comparison"]["improvements"]])
print("archive:", entry)
