use nosh_core::{prompt::{self, Environment}, tools::{self, ToolSet}};
use nosh_llm::{template, tokenizer::Tok};
use nosh_shell::{EmbeddedShell, ShellOptions};
use serde_json::json;

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut tok = Tok::load(std::path::Path::new(&args[1])).unwrap();
    let shell = EmbeddedShell::new(ShellOptions::default()).unwrap();
    let env = Environment::detect(&shell);
    let full = prompt::system_prompt(&env);
    let readonly = format!("{full}\nAttachment mode: run_command is unavailable. Answer from the attachment and the supplied read-only tools; do not request execution.");
    let suggest = prompt::suggest_system_prompt(&env);
    let mut rows = Vec::new();
    for (name, system, set) in [
        ("Full", full, ToolSet::Full),
        ("ReadOnly", readonly, ToolSet::ReadOnly),
        ("Suggest", suggest, ToolSet::Suggest),
    ] {
        let tools = tools::specs(set);
        rows.push(json!({
            "mode": name,
            "system": system,
            "tools": tools.iter().map(|t| json!({"name":t.name,"description":t.description,"parameters":t.parameters})).collect::<Vec<_>>(),
            "system_only_tokens": tok.encode(&system, true).unwrap().len(),
            "static_prefix_tokens": tok.encode_segments(&template::render_system(Some(&system), &tools)).unwrap().len(),
        }));
    }
    println!("{}", serde_json::to_string_pretty(&rows).unwrap());
}
