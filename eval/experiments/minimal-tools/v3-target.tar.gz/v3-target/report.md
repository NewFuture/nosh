# nosh real-model evaluation

Run: `minimal-v3-target-temp1`. Observation: `native-v1`. Source: `1993da25c27b200f72f156a805de523418d6c8ff`. Binary SHA-256: `5ee32c6b3dbe3d824a6ed8bc9e0f7895f73ea7ab61ef5fee6e5979ba4d56517c`.

Harness source: `da49b2c135e0f3053eb8144e3b85f7dfef570676b6316ec80a00c7f015453041`.

Seeds: `[0, 1, 2, 3, 4]`; repeats: 2. Each scenario/seed starts a new process. The typo scenario does not load a model.

| Scenario | Passed/planned | Failed / error / missing | Steps (mean) | Confirmations (mean) | TTFT (median s) | Process time (median s) | Peak RSS (max MiB) |
|---|---:|---:|---:|---:|---:|---:|---:|
| language-lines | 1/10 (10%) | 8 / 1 / 0 | 5.33 | 0.00 | 5.89 | 64.14 | 2582.30 |
| suggest-archive | 10/10 (100%) | 0 / 0 / 0 | 1.00 | 0.00 | 1.39 | 4.01 | 2323.83 |

TTFT is the engine's first-step time to its first sampled token, excluding model loading. Process time includes loading, terminal interactions, and shutdown, but excludes fixture setup. A fresh process has a cold conversation/KV cache, not necessarily a cold OS page cache. RSS is Linux wait4 ru_maxrss for each nosh process (including the kernel's accounting of waited-for descendants, not a sum of a process tree); the listener/verifier are separate. Timing aggregates include failed executions with available measurements. JSON contains sample counts and all raw values.

The suite rebuilds the MVP task intents, not the unavailable original fixtures. These objective pass rates are not directly comparable to the old manual correctness grades or warm-session timings.

## Previous run
Compared with `20260925T060719.060987Z`: 20 paired trials, 1 pass-to-nonpass changes, 5 nonpass-to-pass changes. Unpaired current/previous: 0/80.
- suite_sha256 differs; paired deltas are descriptive, not a controlled regression
- harness sources differ; paired deltas are descriptive, not a controlled regression
- observed sampling parameters differ

| Scenario / seed / repeat | Before → after | Δ steps | Δ confirmations | Δ TTFT s | Δ time s | Δ RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| language-lines / 0 / 0 | fail → error | N/A | 0.00 | N/A | 198.20 | 172.41 |
| language-lines / 1 / 0 | fail → fail | 4.00 | 0.00 | 0.17 | 35.82 | 46.16 |
| language-lines / 2 / 0 | pass → fail | 7.00 | 0.00 | -0.02 | 128.62 | 162.30 |
| language-lines / 3 / 0 | fail → fail | 3.00 | 0.00 | 0.97 | 107.77 | 81.23 |
| language-lines / 4 / 0 | fail → fail | 7.00 | 0.00 | 0.55 | 93.83 | 108.45 |
| suggest-archive / 0 / 0 | pass → pass | 0.00 | 0.00 | -0.91 | -2.67 | -32.04 |
| suggest-archive / 1 / 0 | fail → pass | 0.00 | 0.00 | -0.73 | -3.08 | 26.62 |
| suggest-archive / 2 / 0 | fail → pass | 0.00 | 0.00 | -0.81 | -3.04 | -27.92 |
| suggest-archive / 3 / 0 | fail → pass | 0.00 | 0.00 | -0.73 | -3.24 | -7.65 |
| suggest-archive / 4 / 0 | pass → pass | 0.00 | 0.00 | -0.84 | -3.10 | -32.21 |
| language-lines / 0 / 1 | fail → fail | -1.00 | 0.00 | 1.15 | 4.72 | 6.15 |
| language-lines / 1 / 1 | fail → fail | 1.00 | 0.00 | 1.29 | 41.70 | 7.20 |
| language-lines / 2 / 1 | fail → fail | -2.00 | 0.00 | 1.78 | -4.34 | -54.68 |
| language-lines / 3 / 1 | fail → fail | -2.00 | 0.00 | 3.08 | -15.69 | -10.96 |
| language-lines / 4 / 1 | fail → pass | -1.00 | 0.00 | 1.31 | 10.40 | -15.68 |
| suggest-archive / 0 / 1 | pass → pass | 0.00 | 0.00 | -0.75 | -2.85 | -28.26 |
| suggest-archive / 1 / 1 | pass → pass | 0.00 | 0.00 | -0.36 | -2.06 | 7.37 |
| suggest-archive / 2 / 1 | fail → pass | 0.00 | 0.00 | -0.62 | -2.84 | -31.98 |
| suggest-archive / 3 / 1 | pass → pass | 0.00 | 0.00 | -0.44 | -3.00 | -8.16 |
| suggest-archive / 4 / 1 | pass → pass | 0.00 | 0.00 | -0.72 | -2.53 | -20.90 |

## Repeatability
8/10 pairs have the same verdict and final state; 1 pairs lack usable execution evidence.

| Scenario / seed / repeat | Verdict + state consistent | Answer changed | Tools changed | Inputs changed |
|---|---|---|---|---|
| language-lines / 0 / 1 | N/A | true | N/A | N/A |
| language-lines / 1 / 1 | true | true | true | true |
| language-lines / 2 / 1 | true | true | true | true |
| language-lines / 3 / 1 | true | true | true | true |
| language-lines / 4 / 1 | false | true | true | true |
| suggest-archive / 0 / 1 | true | false | false | true |
| suggest-archive / 1 / 1 | true | false | false | true |
| suggest-archive / 2 / 1 | true | false | false | true |
| suggest-archive / 3 / 1 | true | false | false | true |
| suggest-archive / 4 / 1 | true | false | false | true |

Dynamic prompt time, tool/recent-command durations, and live PIDs can change model inputs. Answer/trace differences are not automatically inference nondeterminism. Interface inputs do not include all internally retained assistant tokens: unchanged interface records are not proof of identical token prompts. See per-trial interface inputs where available.

## Per-trial answers and evidence

Display copies below omit line-end whitespace; JSON retains the recorded answer text.

### language-lines / seed 0 / repeat 0: error

- DriverError: timed out waiting for completion of input 1
```text
(no answer)
```

### language-lines / seed 1 / repeat 0: fail

- incorrect total line count: 36
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
Here are the line counts grouped by language for this project:

**Lines of code by language:**

| Language | Lines |
|----------|-------|
| Python (`.py`) | 15 (main.py, maths.py, report.py) |
| Rust (`.rs`) | 6 (src/main.rs) |
| JavaScript (`.js`) | 4 (web/app.js) |
| Shell (`.sh`) | 4 (scripts/check.sh) |

**Summary:** 6 files total with 36 lines of code across 4 languages.
```

### language-lines / seed 2 / repeat 0: fail

- task did not complete: incomplete
- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
Based on the analysis, I was able to count lines of code by file type in the `/tmp/nosh-eval-1000/language-lines/files` project. The results show:

**Lines of code by language/filename:**
- 5 lines: 3 files
- 4 lines: 2 files
- 6 lines: 1 file
- 29 lines: 1 file

However, I attempted this approach multiple times using different filename extensions. It appears only specific filenames with these line counts were being detected. To get a complete picture, you would need to:

1. Run a more comprehensive command that examines all files, not just by known extensions
2. Also count lines in other file types that weren't matched (like .git, .txt, .md, etc.)
3. Consider using `find` without extension filters to capture files that don't follow common naming patterns

Would you like me to run a more thorough analysis that doesn't rely on specific extensions, or would you prefer to see a summary of all files in the project regardless of type?
```

### language-lines / seed 3 / repeat 0: fail

- incorrect total line count: 34
- no unambiguous javascript line count
- no unambiguous shell line count
```text
Here are the line counts grouped by language for this project:

**File-by-file breakdown:**
- `./scripts/check.sh` (.sh): 4 lines
- `./src/main.rs` (.rs): 6 lines
- `./web/app.js` (.js): 4 lines
- `./tools/report.py` (.py): 5 lines
- `./lib/maths.py` (.py): 5 lines
- `./main.py` (.py): 5 lines

**By language:**
- **Python (.py):** 15 lines (report.py: 5, maths.py: 5, main.py: 5)
- **Rust (.rs):** 6 lines (main.rs)
- **JavaScript (.js):** 4 lines (app.js)
- **Shell (.sh):** 4 lines (check.sh)

**Total:** 34 lines of code across 6 files.
```

### language-lines / seed 4 / repeat 0: fail

- task did not complete: incomplete
- python: expected 15, found [13]
````text
[Summary]
Based on the line counts found in the `/tmp/nosh-eval-1000/language-lines/files` directory, the code is distributed across 6 distinct languages. The breakdown is:

- Python (3 files): 13 lines
- JavaScript (1 file): 4 lines
- Rust (1 file): 6 lines
- Bash (1 file): 4 lines

**Total lines:** 29

**Next step:** To get a complete picture, you should verify the line counts for each file to ensure accuracy before proceeding with any analysis. If you need further aggregation or analysis, you can use a simpler approach like:

```bash
find . -type f -exec wc -l {} + | sort -k1 -n
```

or run a Python script to do the grouping more robustly.
````

### suggest-archive / seed 0 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 1 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 2 / repeat 0: pass

```text
tar -czf logs.tar.gz logs/
```

### suggest-archive / seed 3 / repeat 0: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 4 / repeat 0: pass

```text
tar -czvf logs.tar.gz logs/
```

### language-lines / seed 0 / repeat 1: fail

- python: expected 15, found [6]
- no unambiguous javascript line count
- rust: expected 6, found [4]
- no unambiguous shell line count
```text
Here's the line count summary for this project's files, grouped by language:

| Language | Lines |
|----------|-------|
| C / TypeScript | 5 |
| RUST | 4 |
| Python | 6 |
| JSON | 29 |

The breakdown shows JSON files contribute the most lines (29), followed by Python (6), C/TypeScript (5), and RUST (4). The remaining 1 file had a single line of code.
```

### language-lines / seed 1 / repeat 1: fail

- shell: expected 4, found [12]
```text
Here are the line counts grouped by language for this project:

| Language | Lines |
|----------|-------|
| Python   | 5 (maths.py) |
| Python   | 5 (main.py) |
| Python   | 5 (report.py) |
| Shell    | 4 (check.sh) |
| Shell    | 4 (check.sh) |
| Shell    | 4 (check.sh) |
| Rust     | 6 (src/main.rs) |
| JavaScript | 4 (web/app.js) |

**Summary:**
- **Python:** 15 lines (3 files, 5 lines each)
- **Shell:** 12 lines (3 files, 4 lines each)
- **Rust:** 6 lines (1 file)
- **JavaScript:** 4 lines (1 file)
- **Total:** 29 lines

Only 6 files contain code across the project, with Python and Shell being the most common languages.
```

### language-lines / seed 2 / repeat 1: fail

- python: expected 15, found [5]
```text
Here's the line count by language in the project:

**Summary by language:**
- Python: 5 lines (from `main.py` and `maths.py`)
- JavaScript: 4 lines (from `app.js`)
- Shell script: 4 lines (from `check.sh`)
- Rust: 6 lines (from `main.rs`)

**Total: 29 lines of code**
```

### language-lines / seed 3 / repeat 1: fail

- no unambiguous python line count
- no unambiguous javascript line count
- no unambiguous rust line count
- no unambiguous shell line count
```text
The project contains 29 lines of code total, broken down by language:

- **6 lines** in Rust (`src/main.rs`)
- **5 lines** in Python (`tools/report.py`, `main.py`, `lib/maths.py`)
- **4 lines** in JavaScript (`web/app.js`)
- **4 lines** in Bash (`scripts/check.sh`)

No other file types were found in the project.
```

### language-lines / seed 4 / repeat 1: pass

```text
Here's the count of lines of code grouped by language:

| Language | Lines |
|----------|-------|
| Rust (`main.rs`) | 6 |
| Python (`report.py`, `main.py`, `maths.py`) | 5 each |
| JavaScript (`app.js`) | 4 |
| Shell (`check.sh`) | 4 |
| **Total** | **29** |

Breakdown:
- **Rust**: 6 lines (1 file)
- **Python**: 15 lines (3 files × 5 lines)
- **JavaScript**: 4 lines (1 file)
- **Shell**: 4 lines (1 file)
- **Grand Total**: 29 lines of code
```

### suggest-archive / seed 0 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 1 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 2 / repeat 1: pass

```text
tar -czf logs.tar.gz logs/
```

### suggest-archive / seed 3 / repeat 1: pass

```text
tar -czf logs.tar.gz logs
```

### suggest-archive / seed 4 / repeat 1: pass

```text
tar -czvf logs.tar.gz logs/
```
